#include "tdas/list.h"
#include "tdas/extra.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct{
  char IDNombre[50] ;
  int cantPersonas ;
  int Hora ;
  char prioridad[15] ;

}grupo ;

int ordenPriori(const char *prioridad){
  //Traduce la prioridad a un valor numérico para facilitar la comparación 
  if(strcmp(prioridad, "VIP") == 0) return 1 ;              
  if(strcmp(prioridad, "Grupo Grande") == 0) return 2 ;
  if(strcmp(prioridad, "Estándar") == 0) return 3 ;
  return -1 ; //retorna -1 como predefinido en caso de que no se inserte una cadena válida
}

int cmpAntes(void *auxA, void *auxB ){
  //permite comparar la prioridad de atención o la Hora en caso de que la anterior sea igual 
  grupo *a = (grupo *) auxA ;
  grupo *b = (grupo *) auxB ;

  int prioriA = ordenPriori(a->prioridad) ;
  int prioriB = ordenPriori(b->prioridad) ;

  if (prioriA != prioriB){
    return prioriA < prioriB ;
  }
  return a->Hora < b->Hora ;
  
}

int leerValidarHora(){
  int Hora ;

  scanf("%d", &Hora) ;
  while(Hora >= 2400 || Hora % 100 >= 60 || Hora < 0){
    puts("Hora inválida, debe estar entre 0000 y 2359 con minutos entre 0 y 59 ") ;
    scanf("%d", &Hora) ;

  }
  return Hora ;

}


// Menú principal
void mostrarMenuPrincipal() {
  limpiarPantalla();
  puts("========================================");
  puts("     Sistema de Gestión de Restaurante");
  puts("========================================");

  puts("1) Registrar cliente");
  puts("2) Asignar prioridad a cliente");
  puts("3) Mostrar lista de espera");
  puts("4) Asignar mesa al siguiente grupo");
  puts("5) Buscar reserva");
  puts("6) Salir");
}

void registrar_clientes(List *Lclientes) {
  //registra un nuevo cliente en la lista
  printf("Registrar nuevo cliente\n");
  getchar() ;
  grupo *cliente = (grupo *) malloc(sizeof(grupo)) ;
  if (cliente == NULL){ // Verifica 
    puts("ERROR 507 : no se pudo reservar memoria") ; //Error 507 en caso de que haya errores relacionados a la memoria, lo busqué en Google
    return ;
  }
  
  puts("Ingresar -ID/Nombre\n         -Cantidad de personas\n         -Hora (Formato 0000)") ;
  scanf("%49[^\n]",cliente->IDNombre) ;
  scanf("%d", &cliente->cantPersonas) ;
  cliente->Hora = leerValidarHora();
  strcpy(cliente->prioridad, "Estándar") ;
  list_sortedInsert(Lclientes, cliente, cmpAntes) ;  
  // la ultima linea inserta el elemento en la lista y lo posiciona segun la hora de llegada (ya que la prioridad es estandar cada vez que entra un nuevo elemento)
  
}

void asignar_prioridad(List *Lclientes){
  char clienteBusc[50] ;
  int opcionPriori ;
  
  puts("Introducir ID/Nombre del cliente") ;
  getchar() ; //quita el salto de linea que quedo al momento de pedir la opcion en el menu de atencion
  scanf("%49[^\n]", clienteBusc) ;
  
  grupo *aux = (grupo *) list_first(Lclientes) ;
  while(aux != NULL){
    if(strcmp(clienteBusc, aux->IDNombre) == 0){ //Verifica que la cadena del cliente buscado esté en la lista
      puts("Ingresar prioridad del cliente \n 1) VIP \n 2) Grupo grande \n 3) Estándar") ;
      scanf("%d", &opcionPriori) ;
      switch (opcionPriori){ //switch numerico que, al igual que en ordenPriori, asigna un valor numérico a la prioridad
        case 1 :
          strcpy(aux->prioridad, "VIP") ;  
          puts("Prioridad asignada: VIP") ;
          break ;
        case 2 :
          strcpy(aux->prioridad, "Grupo Grande") ;
          puts("Prioridad asignada: Grupo Grande") ;
          break ;
        case 3 :
          strcpy(aux->prioridad, "Estándar") ;
          puts("Prioridad asignada: Estándar") ;
          break ;
        default :
          puts("Opción no válida. Por favor, intente de nuevo.") ;
        return ;
    }
    //Al reasignarle la prioridad a un grupo de clientes se elimina de la lista original 
    //pero automaticamente se le aplica un sortedInsert para que esta vez si quede posicionado según su prioridad
    list_popCurrent(Lclientes) ;  
    list_sortedInsert(Lclientes, aux, cmpAntes) ;
      
    return ;
    }
    aux = (grupo *) list_next(Lclientes) ; //avanza la lista
  }
  puts("Cliente no encontrado") ;




}

void mostrar_lista_clientes(List *Lclientes) {

  printf("- Hay %d clientes en la lista de espera - ", list_size(Lclientes)) ;
  printf("\n------------------------------------------\n") ;

  grupo *aux = (grupo *) list_first(Lclientes) ; //Asigna un aux para recorrer la lista de clientes
  while(aux != NULL){
    printf("ID/Nombre: %s || Personas: %d || Prioridad %s || Hora: %d \n", aux->IDNombre, aux->cantPersonas, aux->prioridad, aux->Hora) ;
    aux = (grupo *) list_next(Lclientes) ; //Avanza la lista de clientes
  } 


  
}

void asignar_mesa(List *Lclientes){

  grupo *sgte = (grupo *) list_first(Lclientes) ; //crea y asigna un sgte que corresponde al siguiente grupo en la lista de atención

  puts("Mesa asignada al grupo :") ;
  printf("ID/Nombre: %s || Personas: %d || Prioridad %s || Hora: %d \n", sgte->IDNombre, sgte->cantPersonas, sgte->prioridad, sgte->Hora) ;
  
  list_popFront(Lclientes) ; //elimina el grupo del cliente atendido

  free(sgte) ; //libera la memorai del sgte
}

void buscar_reserva(List *Lclientes){
  char clienteBusc[50] ;

  puts("Introducir ID/Nombre del cliente") ;
  getchar() ; //quita el salto de linea que quedo al momento de pedir la opcion en el menu de atencion
  scanf("%49[^\n]", clienteBusc) ;
  
  grupo *aux = (grupo *) list_first(Lclientes) ;
  
  while(aux != NULL){
    if(strcmp(clienteBusc, aux->IDNombre) == 0){ //si el aux->nombre coincide con el buscado imprime los datos
       printf("ID/Nombre: %s || Personas: %d || Prioridad %s || Hora: %d \n", aux->IDNombre, aux->cantPersonas, aux->prioridad, aux->Hora) ;       
      return ;
    }
    aux = (grupo *) list_next(Lclientes) ;

  }
  puts("Cliente no encontrado") ;
}

int main() {
  char opcion;
  List *Lclientes = list_create(); // puedes usar una lista para gestionar los clientess

  do {
    mostrarMenuPrincipal();
    printf("Ingrese su opción: ");
    scanf(" %c", &opcion); // Nota el espacio antes de %c para consumir el
                           // newline anterior
    switch (opcion) {
    case '1':
      registrar_clientes(Lclientes);
      break;
    case '2':
      // Lógica para asignar prioridad
      if(list_first(Lclientes) == NULL){ //Verifica que la lista tenga elementos 
        puts("No hay clientes en la lista") ;
        break ;
      }
      asignar_prioridad(Lclientes) ;
      break;
    case '3':
      if (list_first(Lclientes) == NULL){ //Verifica que la lista tenga elementos 
        puts("No hay clientes en lista") ;
        break; 
      }
      mostrar_lista_clientes(Lclientes);
      
      break;
    case '4':
      if (list_first(Lclientes) == NULL){ //Verifica que la lista tenga elementos 
        puts("No hay clientes en lista") ;
        break; 
      }
      asignar_mesa(Lclientes) ;
      
      break;
    case '5':
      if (list_first(Lclientes) == NULL){ //Verifica que la lista tenga elementos 
        puts("No hay clientes en lista") ;
        break;
      }
      buscar_reserva(Lclientes) ;
      
      break;
    case '6':
      puts("Saliendo del sistema de gestión de restaurante...");
      break;
    default:
      puts("Opción no válida. Por favor, intente de nuevo.");
    }
    presioneTeclaParaContinuar();

    
  }while (opcion != '6');

  // Liberar recursos, si es necesario
  list_clean(Lclientes);

  return 0;
}
